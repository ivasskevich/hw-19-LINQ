﻿namespace LINQ
{
    class Citizen
    {
        public string FullName { get; set; }
        public int Years { get; set; }
        public string Hometown { get; set; }
    }

    class Program
    {
        static void Main()
        {
            var citizens = new List<Citizen>
            {
                new Citizen { FullName = "Andrey", Years = 24, Hometown = "Kyiv" },
                new Citizen { FullName = "Liza", Years = 18, Hometown = "Odesa" },
                new Citizen { FullName = "Oleg", Years = 15, Hometown = "London" },
                new Citizen { FullName = "Sergey", Years = 55, Hometown = "Kyiv" },
                new Citizen { FullName = "Sergey", Years = 32, Hometown = "Lviv" }
            };

            Console.WriteLine("1 =============");
            var olderCitizens = citizens.GroupBy(c => c.Years > 25)
                .Where(g => g.Key)
                .SelectMany(g => g);

            foreach (var person in olderCitizens)
            {
                Console.WriteLine($"{person.FullName}, Age: {person.Years}, City: {person.Hometown}");
            }

            Console.WriteLine("\n2 =============");
            var notFromLondon = citizens
                .Where(c => !string.Equals(c.Hometown, "London", StringComparison.OrdinalIgnoreCase))
                .ToList();

            foreach (var person in notFromLondon)
            {
                Console.WriteLine($"{person.FullName}, Age: {person.Years}, City: {person.Hometown}");
            }

            Console.WriteLine("\n3 =============");
            var namesFromKyiv = citizens
                .FindAll(c => c.Hometown == "Kyiv")
                .Select(c => c.FullName)
                .ToArray();

            foreach (var name in namesFromKyiv)
            {
                Console.WriteLine(name);
            }

            Console.WriteLine("\n4 =============");
            foreach (var person in citizens)
            {
                if (person.Years > 35 && person.FullName == "Sergey")
                {
                    Console.WriteLine($"{person.FullName}, Age: {person.Years}, City: {person.Hometown}");
                }
            }

            Console.WriteLine("\n5 =============");
            citizens.ForEach(person =>
            {
                if (person.Hometown == "Odesa")
                {
                    Console.WriteLine($"{person.FullName}, Age: {person.Years}, City: {person.Hometown}");
                }
            });
        }
    }
}
